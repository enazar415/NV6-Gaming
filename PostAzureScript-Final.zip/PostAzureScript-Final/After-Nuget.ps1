function InstallCommonSoftware {
# Downloading and installing most common software
    # Installing Chrome + Adblock Plus
        ProgressWriter -Status "Installing Chrome + Adblock Plus" -PercentComplete $PercentComplete
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install adblockpluschrome" -Wait -NoNewWindow | Out-Null
    # Downloading and installing WinRAR
        ProgressWriter -Status "Installing WinRAR" -PercentComplete $PercentComplete
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install winrar" -Wait -NoNewWindow | Out-Null
    # Installing qBittorrent
        ProgressWriter -Status "Installing qBittorrent" -PercentComplete $PercentComplete
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install qbittorrent" -Wait -NoNewWindow | Out-Null
    # Installing NotePad++
        ProgressWriter -Status "Installing NotePad++" -PercentComplete $PercentComplete
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install notepadplusplus.install" -Wait -NoNewWindow | Out-Null 
    # Installing CCleaner
         ProgressWriter -Status "Installing CCleaner" -PercentComplete $PercentComplete
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install ccleaner" -Wait -NoNewWindow | Out-Null
    # Downloading and installing required DirectX libraries
        ProgressWriter -Status "Installing DirectX" -PercentComplete $PercentComplete
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install directx" -Wait -NoNewWindow | Out-Null
}