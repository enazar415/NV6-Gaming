function InstallCommonSoftware {
# Downloading and installing most common software
    # Installing Chrome + Adblock Plus
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install adblockpluschrome" -Wait -NoNewWindow | Out-Null
    # Downloading and installing WinRAR
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install winrar" -Wait -NoNewWindow | Out-Null
    # Installing qBittorrent
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install qbittorrent" -Wait -NoNewWindow | Out-Null
    # Installing NotePad++
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install notepadplusplus.install" -Wait -NoNewWindow | Out-Null 
    # Installing CCleaner
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install ccleaner" -Wait -NoNewWindow | Out-Null
    # Downloading and installing required DirectX libraries
        Start-Process -FilePath "$env:PROGRAMDATA\chocolatey\bin\choco.exe" -ArgumentList "install directx" -Wait -NoNewWindow | Out-Null
}

InstallCommonSoftware